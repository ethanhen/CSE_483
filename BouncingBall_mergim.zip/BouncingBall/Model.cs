﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// observable collections
using System.Collections.ObjectModel;

// debug output
using System.Diagnostics;

// timer, sleep
using System.Threading;

using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows;

// hi res timer
using System.Threading;

// Rectangle
// Must update References manually
using System.Drawing;

// INotifyPropertyChanged
using System.ComponentModel;

namespace BouncingBall
{
    public partial class Model : INotifyPropertyChanged
    {

        public ObservableCollection<MyShape> r1c;
        public ObservableCollection<MyShape> r2c;
        public ObservableCollection<MyShape> r3c;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private SolidColorBrush clear = new SolidColorBrush();
        private SolidColorBrush black = new SolidColorBrush();

        private static UInt32 _numBalls = 1;
        private UInt32[] _buttonPresses = new UInt32[_numBalls];
        Random _randomNumber = new Random();

        public static int rowcount = 15;

        public int score = 0;

        private double _ballXMove = 1;
        private double _ballYMove = 1;
        System.Drawing.Rectangle _ballRectangle;
        System.Drawing.Rectangle _paddleRectangle;
        System.Drawing.Rectangle _block;
        bool _movepaddleLeft = false;
        bool _movepaddleRight = false;
        private bool _moveBall = false;

        private Thread threadX = null;
        private bool threadSuspended = false;

        public bool MoveBall
        {
            get { return _moveBall; }
            set { _moveBall = value; }
        }

        private double _windowHeight = 100;
        public double WindowHeight
        {
            get { return _windowHeight; }
            set { _windowHeight = value; }
        }

        private double _windowWidth = 100;
        public double WindowWidth
        {
            get { return _windowWidth; }
            set { _windowWidth = value; }
        }

        private String _score;
        public String Score
        {
            get { return _score; }
            set
            {
                _score = value;
                OnPropertyChanged("Score");
            }
        }
            

        /// <summary>
        /// Model constructor
        /// </summary>
        /// <returns></returns>
        public Model()
        {
        }

        public void threadFunction()
        {
            while (!threadSuspended)
            {
                //if (!_moveBall)
                    //return;

                ballCanvasLeft += _ballXMove;
                ballCanvasTop += _ballYMove;

                // check to see if ball has it the left or right side of the drawing element
                if ((ballCanvasLeft + BallWidth >= _windowWidth) ||
                    (ballCanvasLeft <= 0))
                    _ballXMove = -_ballXMove;


                // check to see if ball has it the top of the drawing element
                if (ballCanvasTop <= 0)
                    _ballYMove = -_ballYMove;

                if (ballCanvasTop + BallHeight >= _windowHeight)
                {
                    // we hit bottom. stop moving the ball
                    _moveBall = false;
                }

                // see if we hit the paddle
                _ballRectangle = new System.Drawing.Rectangle((int)ballCanvasLeft, (int)ballCanvasTop, (int)BallWidth, (int)BallHeight);
                if (_ballRectangle.IntersectsWith(_paddleRectangle))
                {
                    // hit paddle. reverse direction in Y direction
                    _ballYMove = -_ballYMove;

                    // move the ball away from the paddle so we don't intersect next time around and
                    // get stick in a loop where the ball is bouncing repeatedly on the paddle
                    ballCanvasTop += 2 * _ballYMove;

                    // add move the ball in X some small random value so that ball is not traveling in the same 
                    // pattern
                    ballCanvasLeft += _randomNumber.Next(5);
                }

                

                

                foreach (MyShape shape in r1c)
                {
                    _ballRectangle = new System.Drawing.Rectangle((int)ballCanvasLeft, (int)ballCanvasTop, (int)BallWidth, (int)BallHeight);
                    _block = new System.Drawing.Rectangle(((int)shape.CanvasLeft), 0, (int)shape.Width, (int)shape.Height);
                    if (_ballRectangle.IntersectsWith(_block) && !shape.IsHit)
                    {
                        _ballYMove = -_ballYMove;
                        ballCanvasTop -= 5 * _ballYMove;
                        ballCanvasLeft += _randomNumber.Next(5);

                        score = score + 1;

                        shape.IsHit = true;
                        shape.Fill = clear;
                        shape.Stroke = clear;
                    }
                }
                foreach (MyShape shape in r2c)
                {
                    _ballRectangle = new System.Drawing.Rectangle((int)ballCanvasLeft, (int)ballCanvasTop, (int)BallWidth, (int)BallHeight);
                    _block = new System.Drawing.Rectangle(((int)shape.CanvasLeft), 50, (int)shape.Width, (int)shape.Height);
                    if (_ballRectangle.IntersectsWith(_block) && !shape.IsHit)
                    {
                        _ballYMove = -_ballYMove;
                        ballCanvasTop -= 5 * _ballYMove;
                        ballCanvasLeft += _randomNumber.Next(5);

                        score = score + 1;

                        shape.IsHit = true;
                        shape.Fill = clear;
                        shape.Stroke = clear;
                    }
                }
                foreach (MyShape shape in r3c)
                {
                    _ballRectangle = new System.Drawing.Rectangle((int)ballCanvasLeft, (int)ballCanvasTop, (int)BallWidth, (int)BallHeight);
                    _block = new System.Drawing.Rectangle(((int)shape.CanvasLeft), 100, (int)shape.Width, (int)shape.Height);
                    if (_ballRectangle.IntersectsWith(_block) && !shape.IsHit)
                    {
                        _ballYMove = -_ballYMove;
                        ballCanvasTop -= 5 * _ballYMove;
                        ballCanvasLeft += _randomNumber.Next(5);

                        score = score + 1;

                        shape.IsHit = true;
                        shape.Fill = clear;
                        shape.Stroke = clear;
                    }
                }

                if (_movepaddleLeft && paddleCanvasLeft > 0)
                    paddleCanvasLeft -= 2;
                else if (_movepaddleRight && paddleCanvasLeft < _windowWidth - paddleWidth)
                    paddleCanvasLeft += 2;

                _paddleRectangle = new System.Drawing.Rectangle((int)paddleCanvasLeft, (int)paddleCanvasTop, (int)paddleWidth, (int)paddleHeight);

                Score = score.ToString();

                Thread.Sleep(5);
            }
        }

        public void InitModel()
        {
            r1c = new ObservableCollection<MyShape>();
            r2c = new ObservableCollection<MyShape>();
            r3c = new ObservableCollection<MyShape>();
            

            ResetGameblocks();

            threadX = new Thread(new ThreadStart(threadFunction));
            threadX.Start();
        }

        public void CleanUp()
        {
            //_ballHiResTimer.Stop();
            //_paddleHiResTimer.Stop();
            threadSuspended = true;
            threadX.Abort();
        }

        public void ResetGameblocks()
        {

            Score = 0.ToString();
            r1c.Clear();
            r2c.Clear();
            r3c.Clear();

            SolidColorBrush rowcolor = new SolidColorBrush();


            rowcolor.Color = System.Windows.Media.Color.FromArgb(255, 255, 0, 0);
            black.Color = System.Windows.Media.Color.FromArgb(255, 0, 0, 0);
            clear.Color = System.Windows.Media.Color.FromArgb(0, 0, 0, 0);

            for (int i = 0; i < rowcount; i++)
            {
                MyShape temp = new MyShape();
                temp.Width = 900 / rowcount;
                temp.Fill = rowcolor;
                temp.Stroke = black;
                temp.CanvasTop = 0;
                temp.CanvasLeft = i * temp.Width;
                temp.IsHit = false;
                temp.Height = 50;
                r1c.Add(temp);

            }

            for (int i = 0; i < rowcount; i++)
            {
                MyShape temp = new MyShape();
                temp.Width = 900 / rowcount;
                temp.Fill = rowcolor;
                temp.Stroke = black;
                temp.CanvasTop = 0;
                temp.CanvasLeft = i * temp.Width;
                temp.IsHit = false;
                temp.Height = 50;
                r2c.Add(temp);
            }

            for (int i = 0; i < rowcount; i++)
            {
                MyShape temp = new MyShape();
                temp.Width = 900 / rowcount;
                temp.Fill = rowcolor;
                temp.Stroke = black;
                temp.CanvasTop = 0;
                temp.CanvasLeft = i * temp.Width;
                temp.IsHit = false;
                temp.Height = 50;
                r3c.Add(temp);
            }
        }
    
        public void SetStartPosition()
        {
            
            BallHeight = 50;
            BallWidth = 50;
            paddleWidth = 120;
            paddleHeight = 10;

            ballCanvasLeft = 400;
            ballCanvasTop = 300;
           
            _moveBall = false;

            paddleCanvasLeft = _windowWidth / 2 - paddleWidth / 2;
            paddleCanvasTop = _windowHeight - paddleHeight;
            _paddleRectangle = new System.Drawing.Rectangle((int)paddleCanvasLeft, (int)paddleCanvasTop, (int)paddleWidth, (int)paddleHeight);
        }

        public void MoveLeft(bool move)
        {
            _movepaddleLeft = move;
        }

        public void MoveRight(bool move)
        {
            _movepaddleRight = move;
        }


        private void BallMMTimerCallback(object o, System.EventArgs e)
        {

            if (!_moveBall)
                return;

            ballCanvasLeft += _ballXMove;
            ballCanvasTop += _ballYMove;

            // check to see if ball has it the left or right side of the drawing element
            if ((ballCanvasLeft + BallWidth >= _windowWidth) ||
                (ballCanvasLeft <= 0))
                _ballXMove = -_ballXMove;


            // check to see if ball has it the top of the drawing element
            if ( ballCanvasTop <= 0) 
                _ballYMove = -_ballYMove;

            if (ballCanvasTop + BallWidth >= _windowHeight)
            {
                // we hit bottom. stop moving the ball
                _moveBall = false;
            }

            // see if we hit the paddle
            _ballRectangle = new System.Drawing.Rectangle((int)ballCanvasLeft, (int)ballCanvasTop, (int)BallWidth, (int)BallHeight);
            if (_ballRectangle.IntersectsWith(_paddleRectangle))
            {
                // hit paddle. reverse direction in Y direction
                _ballYMove = -_ballYMove;

                // move the ball away from the paddle so we don't intersect next time around and
                // get stick in a loop where the ball is bouncing repeatedly on the paddle
                ballCanvasTop += 2*_ballYMove;

                // add move the ball in X some small random value so that ball is not traveling in the same 
                // pattern
                ballCanvasLeft += _randomNumber.Next(5);
            }

        }

        private void PaddleMMTimerCallback(object o, System.EventArgs e)
        {
            if (_movepaddleLeft && paddleCanvasLeft > 0)
                paddleCanvasLeft -= 2;
            else if (_movepaddleRight && paddleCanvasLeft < _windowWidth - paddleWidth)
                paddleCanvasLeft += 2;
            
            _paddleRectangle = new System.Drawing.Rectangle((int)paddleCanvasLeft, (int)paddleCanvasTop, (int)paddleWidth, (int)paddleHeight);
        }  
    }
}
